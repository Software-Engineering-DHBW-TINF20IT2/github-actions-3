import sys

print("Running Backend...")
print("Python version is: " + sys.version)

sys.exit(0)

