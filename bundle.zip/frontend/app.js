console.log('Running app...');
console.log('Node.js version is: ' + process.version)

